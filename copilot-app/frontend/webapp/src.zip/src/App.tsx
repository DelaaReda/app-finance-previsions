import { RouterProvider, createBrowserRouter, createRoutesFromElements, Route, Outlet } from 'react-router-dom'
import { AppProviders } from './app/providers'
import GlobalErrorBoundary from './components/system/GlobalErrorBoundary'; // Global error boundary for stability
import AppShell from './layout/AppShell'; // Using the new MUI-based layout
import { DrillDownProvider } from './contexts/DrillDownContext'; // FC-INT-027: Intelligent drill-down navigation
import { CommandPalette } from './components/system/CommandPalette'; // FC-UX-001: Command Palette (Ctrl+K)
import { useCommandPalette } from './hooks/useCommandPalette'; // FC-UX-001: Command Palette hook
import DevDebugPanel from './debug/DevDebugPanel';

// Pages existantes
import Dashboard from './pages/Dashboard'
import Forecasts from './pages/Forecasts'
import LLMJudge from './pages/LLMJudge'
import Backtests from './pages/Backtests'
import CompareStrategies from './pages/CompareStrategies'
import DashboardsPage from './pages/Dashboards'

// Nouvelles pages selon VISION
import Macro from './pages/Macro'
import Stocks from './pages/Stocks'
import News from './pages/News'
import NewsSignalRadar from './pages/NewsSignalRadar' // FC-UX-002: News Signal Radar (Treemap visualization)
import Copilot from './pages/Copilot'
import TickerDetail from './pages/TickerDetail' // FC-INT-027: Replaces TickerSheet with intelligent drill-down
import MarketBrief from './pages/MarketBrief'
import Portfolios from './pages/Portfolios' // API-PORTFOLIO-002: Portfolio/Watchlist management
import HealthPage from './pages/Health' // FC-PHASE1-002: Health & Freshness Overview
import Diagnostics from './pages/Diagnostics' // Correlation analysis
import Analytics from './pages/Analytics' // Capital flows analysis
import Trading from './pages/Trading' // OrderBook visualization
import TestSimple from './pages/TestSimple'

// AppContent wrapper with Command Palette
function AppContent() {
  const { opened, close } = useCommandPalette();
  const isDev = import.meta.env.DEV;
  
  return (
    <>
      <CommandPalette opened={opened} close={close} />
      <Outlet />
      {isDev && <DevDebugPanel />}
    </>
  );
}

// Create router with error boundary wrapper, drill-down context, and command palette
const router = createBrowserRouter(
  createRoutesFromElements(
  <Route element={
    <GlobalErrorBoundary>
      <DrillDownProvider>
        <AppShell>
          <AppContent />
        </AppShell>
      </DrillDownProvider>
    </GlobalErrorBoundary>
  }>
    <Route index element={<Dashboard />} />
    <Route path="/brief" element={<MarketBrief />} />
    <Route path="/macro" element={<Macro />} />
    <Route path="/stocks" element={<Stocks />} />
    <Route path="/news" element={<News />} />
    <Route path="/news/radar" element={<NewsSignalRadar />} /> {/* FC-UX-002: News Signal Radar */}
    <Route path="/copilot" element={<Copilot />} />
    <Route path="/portfolios" element={<Portfolios />} /> {/* API-PORTFOLIO-002: Portfolio management */}
    <Route path="/health" element={<HealthPage />} /> {/* FC-PHASE1-002: Health & Freshness Overview */}
    <Route path="/diagnostics" element={<Diagnostics />} /> {/* Correlation analysis */}
    <Route path="/analytics" element={<Analytics />} /> {/* Capital flows analysis */}
    <Route path="/trading" element={<Trading />} /> {/* OrderBook visualization */}
    <Route path="/ticker/:ticker" element={<TickerDetail />} /> {/* FC-INT-027: Intelligent drill-down */}
    <Route path="/forecasts" element={<Forecasts />} />
    <Route path="/test" element={<TestSimple />} />
    <Route path="/backtests" element={<Backtests />} />
    <Route path="/compare" element={<CompareStrategies />} />
    <Route path="/dashboards/:slug?" element={<DashboardsPage />} />
    <Route path="/judge" element={<LLMJudge />} />
  </Route>,
),
{
  future: {
    v7_normalizeFormMethod: true,
    v7_partialHydration: true,
    v7_relativeSplatPath: true,
    v7_skipActionErrorRevalidation: true,
    v7_startTransition: true,
  },
});

export default function App() {
  return (
    <AppProviders>
      <RouterProvider
        router={router}
        future={{
          v7_startTransition: true,
        }}
      />
    </AppProviders>
  )
}
